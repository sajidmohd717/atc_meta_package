

//Cuda / Cudnn / TensorRT / tkDNN installation for atc_detector

// 1) Open "Additional drivers" and install nvidia-driver-465 (proprietary)

// 2) Install Cuda 10.1 for Ubuntu 20.04 (Synaptic)
// https://linuxconfig.org/how-to-install-cuda-on-ubuntu-20-04-focal-fossa-linux
$ sudo apt update
$ sudo apt install nvidia-cuda-toolkit
$ nvcc --version
$ wget -O /etc/apt/preferences.d/cuda-repository-pin-600 https://developer.download.nvidia.com/compute/cuda/repos/ubuntu1804/x86_64/cuda-ubuntu1804.pin
$ sudo apt-key adv --fetch-keys https://developer.download.nvidia.com/compute/cuda/repos/ubuntu1804/x86_64/7fa2af80.pub
$ sudo add-apt-repository "deb http://developer.download.nvidia.com/compute/cuda/repos/ubuntu1804/x86_64/ /"

// 2) Install Cudnn8-dev (Synaptic)

// 3) Install TensorRT-7.1.3.4 (unzip *.tar source)

//-------------------------------------------------------------------------------------------
// 3.5) Serialise the weights (due to different systems used ARM vs x86)
Use the following fork of Alexey's darknet repository:
https://git.hipert.unimore.it/fgatti/darknet

Config file is located in the perception_training repository -> tkdnn branch
https://git.siotgov.tech/decada_robotics/perception_training/src/branch/tkdnn/yolo-obj.cfg

Weights file is located here
https://drive.google.com/file/d/1D1b8hkAbfBYMtO3Y3g9Zr51-Nty0U3AM/view?usp=drivesdk

1. Run the following command with the configuration files named yolo-obj.cfg, and weights of your preference. No changes are needed to be made to the makefile as it is okay to let darknet run on CPU to serialise each individual layers.
In the outermost directory of the darknet repository, run the following commands
```bash
mkdir layers
make 
./darknet export <path-to-cfg-file> <path-to-weights> layers

ie:
./darknet export yolo-obj.cfg yolo-obj_5000.weights layers
```
2. The files will be exported to layers/
3. Copy the files from the layers folder and put it in the [tkDNN-mod/build/yolov4/layers] folder


//-------------------------------------------------------------------------------------------
// 4) Compile tkDNN (specify include and lib drive as /media/Data/workspace/free_fleet/TensorRT-7.1.3.4/targets/x86_64-linux-gnu, for example)
// https://github.com/ceccocats/tkDNN
// Before build, do
export TKDNN_MODE=FP16  # set the half floating point optimization
rm yolo4_fp16.rt        # be sure to delete(or move) old tensorRT files
./test_yolo4            # run the yolo test (is slow)
./demo yolo4_fp16.rt ../demo/yolo_test.mp4 y
- Copy and past [yolo4_fp16.rt] over to the install folder 

// 5a) Copy libkernels.so, libtkDNN.so to the atc_detector install/share directories (where atc_detector_node runs from)
// 5b) Add following lines to ~/.bashrc
export LD_LIBRARY_PATH=/usr/local/cuda-10.2/lib64:/media/Data/workspace/free_fleet/TensorRT-7.1.3.4/targets/x86_64-linux-gnu/lib:/media/Data/workspace/free_fleet/client_ws/install/atc_detector/share/atc_detector:$LD_LIBRARY_PATH


