#ifndef __ROS_BOILERPLATE_H__
#define __ROS_BOILERPLATE_H__

#include <ros/ros.h>
#include <std_msgs/Bool.h>
#include <iostream>
#include <signal.h>
#include <stdlib.h>     /* srand, rand */
#include <unistd.h>
#include <mutex>
#include "Yolo3Detection.h"
#include <cv_bridge/cv_bridge.h>
#include <sensor_msgs/Image.h>
#include <sensor_msgs/CameraInfo.h>

// Mod by Tim:
//#include <atc_detector/box.h>
//#include <atc_detector/box_array.h>
#include <atc_msgs/Detector.h>

#include <image_transport/image_transport.h>

static int count; 

class TrolleyDetector {
 public:
  TrolleyDetector(ros::NodeHandle *nodeHandle);

	bool init();
	bool realsense = true;
	bool state_encode_bool = false;
	bool work();

	cv::VideoCapture cap;
	cv::VideoWriter resultVideo;
	cv::Mat dnn_input;
	cv::Mat frame;
	
	// Declare inference networks 
	tk::dnn::Yolo3Detection yolo;
	tk::dnn::DetectionNN *detNN;  
	
	// Configure parameters
	std::string workingPath;
	std::string videoSource;

	// Configure callbacks
	//void InferCB(const sensor_msgs::ImageConstPtr &msg);
	void InferCB(const sensor_msgs::ImageConstPtr &msg, const sensor_msgs::CameraInfoConstPtr& camera_info);

	void CamInfoCB(const sensor_msgs::CameraInfoConstPtr &msg);
	void StateEncodeCB(const std_msgs::BoolConstPtr &msg);

 protected:
	ros::NodeHandle *nodeHandle_;

	// Subcriber
  	//ros::Subscriber subscriber_image;
  	ros::Subscriber subscriber_autoencode;

  	// Mod by Tim:
  	std::shared_ptr<image_transport::ImageTransport> it_;
  	image_transport::CameraSubscriber camera_image_subscriber_;

	// Publisher
	image_transport::Publisher publisher_img;
  	ros::Publisher publisher_bb;
	ros::Publisher publisher_prete;

	// Trolley detector initialised state indicator
	std_msgs::Bool state_initialised;

	int counter_;
	int w;
	int h;

	bool record = false;
	bool show = false;

	// Mod by Tim:
	bool hasStoppedAGV = false;
};

#endif  // __ROS_BOILERPLATE_H__
