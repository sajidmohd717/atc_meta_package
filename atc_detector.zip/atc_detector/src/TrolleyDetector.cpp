

#include <ros/ros.h>
#include "TrolleyDetector.h"

TrolleyDetector::TrolleyDetector(ros::NodeHandle *nodeHandle)
    : nodeHandle_(nodeHandle)
{
  counter_ = 0;
}

//-------------------------------------------------------------------------------------------------
bool TrolleyDetector::init() {
	// Initialising publishers and subscribers
	image_transport::ImageTransport it(*nodeHandle_);
	publisher_img = it.advertise("/detection/image", 10);

	// Mod by Tim:
	//publisher_bb = nodeHandle_->advertise<atc_detector::box_array>("/detection/bounding_boxes", 10);
	publisher_bb = nodeHandle_->advertise<atc_msgs::Detector>("/detection/bounding_boxes", 10);

	publisher_prete = nodeHandle_->advertise<std_msgs::Bool>("/detection/state_yolo", 10);
	//ROS_INFO_STREAM("Started subscriber " << subscriber_);

	// Indicate that state has not yet fully initialised and publish it
	state_initialised.data = true;
	publisher_prete.publish(state_initialised);

	// Obtain parameters
	nodeHandle_->getParam("/atc_detector_node/working_path", workingPath);
	nodeHandle_->getParam("/atc_detector_node/record", record);
	nodeHandle_->getParam("/atc_detector_node/show", show);

	//std::string input = "../demo/yolo_test.mp4";
	int n_classes = 3;
	std::stringstream weights;
	weights << workingPath << "/yolo4_fp16.rt";
	ROS_INFO_STREAM("Weights path " << weights.str());
	TrolleyDetector::detNN = &yolo;
	TrolleyDetector::detNN->init(weights.str(), n_classes);
	std::cout << "YOLO initialised" << std::endl;

	publisher_prete.publish(state_initialised);

	// Initialise the subscribers
	// Mod by Tim:
	//subscriber_image = nodeHandle_->subscribe("/image_raw", 10, &TrolleyDetector::InferCB, this);
	it_ = std::shared_ptr<image_transport::ImageTransport>( new image_transport::ImageTransport(*nodeHandle_));
	camera_image_subscriber_ = it_->subscribeCamera("/image_raw", 1, &TrolleyDetector::InferCB, this);
	subscriber_autoencode = nodeHandle_->subscribe("/autoencoder/state_autoencoder", 10, &TrolleyDetector::StateEncodeCB, this);

  return true;
}

//-------------------------------------------------------------------------------------------------
void TrolleyDetector::StateEncodeCB(const std_msgs::BoolConstPtr &msg)
{
	state_encode_bool = msg->data;
}

//-------------------------------------------------------------------------------------------------
//void TrolleyDetector::InferCB(const sensor_msgs::ImageConstPtr &msg)
void TrolleyDetector::InferCB(const sensor_msgs::ImageConstPtr &msg, const sensor_msgs::CameraInfoConstPtr& camera_info)
{
	//ROS_WARN("TrolleyDetector::InferCB()...");

	cv_bridge::CvImagePtr cv_ptr = cv_bridge::toCvCopy(msg, sensor_msgs::image_encodings::BGR8);
	frame = cv_ptr->image;
	cv::imshow("Attempted Inference" , frame);
	// this will be resized to the net format
	dnn_input = frame.clone();
	detNN->update(dnn_input);
	detNN->draw(frame);
	std::vector<tk::dnn::box> boxes = detNN->detected; //Previously detNN->processed_bb;
	
	// Mod by Tim:
	//atc_detector::box_array box_arr;
	atc_msgs::Detector box_arr;

	std_msgs::Header header;
	for (std::vector<tk::dnn::box>::iterator b = boxes.begin(); b != boxes.end(); b++) {
		// Declare variables
		tk::dnn::box box_ = *b;
		atc_msgs::BoundingBox box_msg;
		box_msg.pixelPosRight = box_.x / (*camera_info).width;;
		box_msg.pixelPosDown = box_.y / (*camera_info).height;
		box_msg.width = box_.w;
		box_msg.height = box_.h;
		//box_arr.header = header;
		box_arr.boxes.push_back(box_msg);
	}

	double mean = 0; 
	for(int i=0; i<detNN->stats.size(); i++) mean += detNN->stats[i]; mean /= detNN->stats.size();
	double fps = 1000.0f / mean;
	//cv::putText(frame,
	//			std::to_string(fps) + " FPS",
	//			cv::Point(5, 25),
	//			cv::FONT_HERSHEY_COMPLEX_SMALL,
	//			1.0,
//			cv::Scalar(0, 255, 0));															
	
	sensor_msgs::ImagePtr img_msg = cv_bridge::CvImage(header, sensor_msgs::image_encodings::BGR8, frame).toImageMsg();
	publisher_img.publish(img_msg);
	publisher_bb.publish(box_arr);
	publisher_prete.publish(state_initialised);

	if (show) {
		cv::imshow("Detection", frame);
		cv::waitKey(1);
	}
		
	if (record) {
       	 std::string filename = workingPath + "/images/image_" + std::to_string(count) + ".png";
	     std::cout << filename << std::endl;
	     cv::imwrite(filename, frame);
	     cv::waitKey(500);
	     count++;
	}

	// Mod by Tim: Interface to Waypoints package. Stop the AGV
//	if((boxes.size() > 0) && (!hasStoppedAGV))
//	{
//		ROS_WARN("TrolleyDector - Detected, stopping AGV...");
//        std::string msg = "rosservice call /waypoint_server/stop_wp";
//        system(msg.c_str());
//        hasStoppedAGV = true;
//
//
//	}

}
