

#include <ros/ros.h>
#include "TrolleyDetector.h"

int main(int argc, char **argv) {
  ros::init(argc, argv, "atc_detector_node");
  ros::NodeHandle nodeHandle;

  TrolleyDetector worker(&nodeHandle);
  if (!worker.init()) {
    ROS_ERROR("Error initializing node.");
    return -1;
  }

  // Allow the subscribers and publishers to connect.
  ros::Duration(0.5).sleep();

  ROS_INFO_STREAM("atc_detector node started");
  ros::Rate rate = ros::Rate(30.0);
  while (ros::ok()) {
    //worker.work();

    // Don't forget to call work to process messages, then sleep.
    ros::spinOnce();
    rate.sleep();
  }

  ROS_INFO_STREAM("atc_detector node finished");
}
